﻿using Microsoft.AspNetCore.Mvc;

namespace RaceDayMVC.Controllers
{
    public class ParticipantController : Controller
    {
        public IActionResult Index()
        {
            // Check whether the user is logged in
            var token = HttpContext.Session.GetString("JWToken");
            var role = HttpContext.Session.GetString("UserRole");

            if (string.IsNullOrEmpty(token) || role != "Participant")
            {
                return RedirectToAction("Login", "Auth");
            }

            return View();
        }
    }
}