﻿using Microsoft.AspNetCore.Mvc;
using RaceDayMVC.Models;
using RaceDayMVC.Services;
using System.Net.Http.Json;
using System.Text.Json;

namespace RaceDayMVC.Controllers
{
    public class AuthController : Controller
    {
        private readonly RaceDayApiService _apiService;

        public AuthController(RaceDayApiService apiService)
        {
            _apiService = apiService;
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            var result = await _apiService.LoginAsync(model);

            if (result == null)
            {
                ModelState.AddModelError("", "Invalid email, password or role.");
                return View(model);
            }

            using var document = JsonDocument.Parse(result);

            var root = document.RootElement;

            string token = root.GetProperty("token").GetString()!;
            string name = root.GetProperty("name").GetString()!;
            string role = root.GetProperty("role").GetString()!;
            string userId = root.GetProperty("userId").ToString();

            HttpContext.Session.SetString("JWToken", token);
            HttpContext.Session.SetString("UserName", name);
            HttpContext.Session.SetString("UserRole", role);
            HttpContext.Session.SetString("UserId", userId);

            if (role == "Organiser")
                return RedirectToAction("Index", "Organiser");

            return RedirectToAction("Index", "Participant");
        }

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            var result = await _apiService.RegisterAsync(model);

            if (result == null)
            {
                ModelState.AddModelError("", "Registration failed. Please check your details.");
                return View(model);
            }

            TempData["Success"] = "Registration successful. Please log in.";

            return RedirectToAction("Login");
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();

            return RedirectToAction("Login");
        }
    }
}