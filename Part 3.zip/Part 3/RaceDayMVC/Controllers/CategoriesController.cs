﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using RaceDayMVC.Models;
using RaceDayMVC.Services;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace RaceDayMVC.Controllers
{
    public class CategoriesController : Controller
    {
        private readonly RaceDayApiService _apiService;

        public CategoriesController(RaceDayApiService apiService)
        {
            _apiService = apiService;
        }

        // ORGANISER: DISPLAY CATEGORIES
        public async Task<IActionResult> Index()
        {
            if (!IsOrganiser())
                return RedirectToAction("Login", "Auth");

            try
            {
                var categories = await _apiService.GetCategoriesAsync();
                return View("ManageCategories", categories);
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return View("ManageCategories",
                    new List<CategoryViewModel>());
            }
        }

        // PARTICIPANT: BROWSE CATEGORIES
        [HttpGet]
        public async Task<IActionResult> Browse()
        {
            if (!IsParticipant())
                return RedirectToAction("Login", "Auth");

            try
            {
                var categories = await _apiService.GetCategoriesAsync();

                return View("BrowseCategories", categories);
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;

                return View("BrowseCategories",
                    new List<CategoryViewModel>());
            }
        }

        // ORGANISER: DISPLAY CREATE CATEGORY FORM
        [HttpGet]
        public async Task<IActionResult> Create()
        {
            if (!IsOrganiser())
                return RedirectToAction("Login", "Auth");

            ViewBag.Events = await _apiService.GetEventsAsync();

            return View("CreateCategory");
        }

        // ORGANISER: SAVE NEW CATEGORY
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CategoryViewModel model)
        {
            if (!IsOrganiser())
                return RedirectToAction("Login", "Auth");

            if (model.MinAge > model.MaxAge)
            {
                ModelState.AddModelError(
                    "MinAge", "Minimum age cannot exceed maximum age.");
            }

            if (!ModelState.IsValid)
            {
                ViewBag.Events = await _apiService.GetEventsAsync();
                return View("CreateCategory", model);
            }

            try
            {
                string token = HttpContext.Session.GetString("JWToken")!;

                await _apiService.CreateCategoryAsync(model, token);

                TempData["Success"] = "Category created successfully!";

                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                ViewBag.Events = await _apiService.GetEventsAsync();
                return View("CreateCategory", model);
            }
        }

        private bool IsOrganiser()
        {
            var token = HttpContext.Session.GetString("JWToken");
            var role = HttpContext.Session.GetString("UserRole");

            return !string.IsNullOrEmpty(token)
                   && role == "Organiser";
        }

        private bool IsParticipant()
        {
            var token = HttpContext.Session.GetString("JWToken");
            var role = HttpContext.Session.GetString("UserRole");

            return !string.IsNullOrEmpty(token)
                   && role == "Participant";
        }
    }
}
