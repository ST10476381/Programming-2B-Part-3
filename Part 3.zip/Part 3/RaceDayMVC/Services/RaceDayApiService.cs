﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Net.Http.Json;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Text.Json;
using RaceDayMVC.Models;
using Microsoft.AspNetCore.Http;

namespace RaceDayMVC.Services
{
    public class RaceDayApiService
    {
        private readonly HttpClient _httpClient;

        public RaceDayApiService(IHttpClientFactory httpClientFactory)
        {
            _httpClient = httpClientFactory.CreateClient("RaceDayAPI");
        }

        // LOGIN
        public async Task<string?> LoginAsync(LoginViewModel model)
        {
            var request = new
            {
                email = model.Email,
                password = model.Password,
                role = model.Role
            };

            var response = await _httpClient.PostAsJsonAsync(
                "api/Auth/login", request);

            var body = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                throw new Exception(
                    $"Login API Error: {(int)response.StatusCode} - {body}");

            return body;
        }

        // REGISTER
        public async Task<string?> RegisterAsync(RegisterViewModel model)
        {
            var request = new
            {
                name = model.Name,
                email = model.Email,
                password = model.Password,
                role = model.Role,
                dateOfBirth = model.DateOfBirth,
                gender = model.Gender,
                phone = model.Phone
            };

            var response = await _httpClient.PostAsJsonAsync(
                "api/Auth/register", request);

            var body = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                throw new Exception(
                    $"Registration API Error: {(int)response.StatusCode} - {body}");

            return body;
        }

        // GET PARTICIPANT PROFILE
        public async Task<ParticipantProfileViewModel?> GetParticipantProfileAsync(
            string token)
        {
            _httpClient.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", token);

            var response = await _httpClient.GetAsync(
                "api/RaceDay/participants");

            var body = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                throw new Exception(
                    $"Get Participant Profile API Error: {(int)response.StatusCode} - {body}");

            return JsonSerializer.Deserialize<ParticipantProfileViewModel>(
                body,
                new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
        }

        // UPDATE PARTICIPANT PROFILE
        public async Task UpdateParticipantProfileAsync(
            ParticipantProfileViewModel model, string token)
        {
            _httpClient.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", token);

            var request = new
            {
                name = model.Name,
                email = model.Email,
                dateOfBirth = model.DateOfBirth,
                gender = model.Gender
            };

            var response = await _httpClient.PutAsJsonAsync(
                "api/RaceDay/participants", request);

            var body = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                throw new Exception(
                    $"Update Participant Profile API Error: {(int)response.StatusCode} - {body}");
        }

        // GET ORGANISER PROFILE
        public async Task<OrganiserProfileViewModel?> GetOrganiserProfileAsync(
            string token)
        {
            _httpClient.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", token);

            var response = await _httpClient.GetAsync(
                "api/RaceDay/organisers/profile");

            var body = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                throw new Exception(
                    $"Get Organiser Profile API Error: {(int)response.StatusCode} - {body}");

            return JsonSerializer.Deserialize<OrganiserProfileViewModel>(
                body,
                new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
        }

        // UPDATE ORGANISER PROFILE
        public async Task UpdateOrganiserProfileAsync(
            OrganiserProfileViewModel model, string token)
        {
            _httpClient.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", token);

            var request = new
            {
                name = model.Name,
                email = model.Email,
                phone = model.Phone
            };

            var response = await _httpClient.PutAsJsonAsync(
                "api/RaceDay/organisers/profile", request);

            var body = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                throw new Exception(
                    $"Update Organiser Profile API Error: {(int)response.StatusCode} - {body}");
        }

        // UPLOAD ORGANISER PROFILE IMAGE
        public async Task UploadOrganiserProfileImageAsync(
            IFormFile image, string token)
        {
            if (image == null || image.Length == 0)
                throw new Exception("Please select an image.");

            using var content = new MultipartFormDataContent();

            using var stream = image.OpenReadStream();

            using var fileContent = new StreamContent(stream);

            fileContent.Headers.ContentType =
                new MediaTypeHeaderValue(
                    string.IsNullOrWhiteSpace(image.ContentType)
                        ? "application/octet-stream"
                        : image.ContentType);

            content.Add(fileContent, "Image", Path.GetFileName(image.FileName));

            using var request = new HttpRequestMessage(
                HttpMethod.Post,
                "api/RaceDay/organisers/profile/image");

            request.Headers.Authorization =
                new AuthenticationHeaderValue("Bearer", token);

            request.Content = content;

            using var response = await _httpClient.SendAsync(request);

            var body = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                throw new Exception(
                    $"Upload Profile Image API Error: {(int)response.StatusCode} - {body}");
        }

        // GET EVENTS
        public async Task<List<EventViewModel>> GetEventsAsync()
        {
            var response = await _httpClient.GetAsync(
                "api/RaceDay/events");

            response.EnsureSuccessStatusCode();

            return await response.Content
                .ReadFromJsonAsync<List<EventViewModel>>()
                ?? new List<EventViewModel>();
        }

        // CREATE EVENT
        public async Task CreateEventAsync(
            CreateEventViewModel model, string token)
        {
            var request = new
            {
                eventName = model.EventName,
                eventDate = model.EventDate,
                location = model.Location,
                description = model.Description,
                eventType = model.EventType,
                distance = model.Distance
            };

            _httpClient.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", token);

            var response = await _httpClient.PostAsJsonAsync(
                "api/RaceDay/events", request);

            var body = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                throw new Exception(
                    $"Create Event API Error: {(int)response.StatusCode} - {body}");

            if (string.IsNullOrWhiteSpace(body))
                throw new Exception(
                    "API returned success but no response body.");

            Console.WriteLine("EVENT CREATED: " + body);
        }

        // UPDATE EVENT
        public async Task UpdateEventAsync(
            int id, CreateEventViewModel model, string token)
        {
            var request = new
            {
                eventName = model.EventName,
                eventDate = model.EventDate,
                location = model.Location,
                description = model.Description,
                eventType = model.EventType,
                distance = model.Distance
            };

            _httpClient.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", token);

            var response = await _httpClient.PutAsJsonAsync(
                $"api/RaceDay/events/{id}", request);

            var body = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                throw new Exception(
                    $"Update Event API Error: {(int)response.StatusCode} - {body}");
        }

        // DELETE EVENT
        public async Task DeleteEventAsync(int id, string token)
        {
            _httpClient.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", token);

            var response = await _httpClient.DeleteAsync(
                $"api/RaceDay/events/{id}");

            var body = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                throw new Exception(
                    $"Delete Event API Error: {(int)response.StatusCode} - {body}");
        }

        // GET CATEGORIES
        public async Task<List<CategoryViewModel>> GetCategoriesAsync()
        {
            var response = await _httpClient.GetAsync(
                "api/RaceDay/categories");

            response.EnsureSuccessStatusCode();

            return await response.Content
                .ReadFromJsonAsync<List<CategoryViewModel>>()
                ?? new List<CategoryViewModel>();
        }

        // CREATE CATEGORY
        public async Task CreateCategoryAsync(
            CategoryViewModel model, string token)
        {
            var request = new
            {
                eventId = model.EventId,
                categoryName = model.CategoryName,
                distance = model.Distance,
                maxParticipants = model.MaxParticipants,
                entryFee = model.EntryFee,
                minAge = model.MinAge,
                maxAge = model.MaxAge
            };

            _httpClient.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", token);

            var response = await _httpClient.PostAsJsonAsync(
                "api/RaceDay/categories", request);

            var body = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                throw new Exception(
                    $"Create Category API Error: {(int)response.StatusCode} - {body}");
        }

        // GET ENROLMENTS
        public async Task<List<EnrolmentViewModel>> GetEnrolmentsAsync(
            string token)
        {
            _httpClient.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", token);

            var response = await _httpClient.GetAsync(
                "api/RaceDay/enrolments");

            var body = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                throw new Exception(
                    $"Enrolments API Error: {(int)response.StatusCode} - {body}");

            return JsonSerializer.Deserialize<List<EnrolmentViewModel>>(
                body,
                new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                })
                ?? new List<EnrolmentViewModel>();
        }

        // CREATE ENROLMENT
        public async Task CreateEnrolmentAsync(
            int categoryId, string token)
        {
            _httpClient.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", token);

            var response = await _httpClient.PostAsJsonAsync(
                "api/RaceDay/enrolments",
                new { categoryId });

            var body = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                throw new Exception(
                    $"Create Enrolment API Error: {(int)response.StatusCode} - {body}");
        }

        // GET RESULTS
        public async Task<List<ResultViewModel>> GetResultsAsync(
            string token)
        {
            _httpClient.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", token);

            var response = await _httpClient.GetAsync(
                "api/RaceDay/results");

            var body = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                throw new Exception(
                    $"Results API Error: {(int)response.StatusCode} - {body}");

            return JsonSerializer.Deserialize<List<ResultViewModel>>(
                body,
                new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                })
                ?? new List<ResultViewModel>();
        }

        // CREATE RESULT
        public async Task CreateResultAsync(
            ResultViewModel model, string token)
        {
            _httpClient.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", token);

            var request = new
            {
                enrolmentId = model.EnrolmentID,
                finishTime = model.FinishTime,
                position = model.Position,
                status = model.Status
            };

            var response = await _httpClient.PostAsJsonAsync(
                "api/RaceDay/results", request);

            var body = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                throw new Exception(
                    $"Create Result API Error: {(int)response.StatusCode} - {body}");
        }
    }
}
