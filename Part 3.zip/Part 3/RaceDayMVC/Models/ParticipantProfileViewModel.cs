﻿
using System;
using System.ComponentModel.DataAnnotations;

namespace RaceDayMVC.Models
{
    public class ParticipantProfileViewModel
    {
        public int ParticipantID { get; set; }

        [Required(ErrorMessage = "Please enter your name.")]
        [StringLength(100)]
        public string Name { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please enter your email.")]
        [EmailAddress(ErrorMessage = "Enter a valid email address.")]
        [StringLength(150)]
        public string Email { get; set; } = string.Empty;

        [DataType(DataType.Date)]
        public DateTime? DateOfBirth { get; set; }

        [StringLength(20)]
        public string? Gender { get; set; }
    }
}
