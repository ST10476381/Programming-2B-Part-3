﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using RaceDayMVC.Models;
using RaceDayMVC.Services;
using System;
using System.Threading.Tasks;

namespace RaceDayMVC.Controllers
{
    public class ProfileController : Controller
    {
        private readonly RaceDayApiService _apiService;

        public ProfileController(RaceDayApiService apiService)
        {
            _apiService = apiService;
        }

        // PARTICIPANT PROFILE - GET
        [HttpGet]
        public async Task<IActionResult> ParticipantProfile()
        {
            string? token = HttpContext.Session.GetString("JWToken");
            string? userRole = HttpContext.Session.GetString("UserRole");

            if (string.IsNullOrEmpty(token) || userRole != "Participant")
                return RedirectToAction("Login", "Auth");

            try
            {
                var profile = await _apiService.GetParticipantProfileAsync(token);

                if (profile == null)
                {
                    TempData["Error"] = "Unable to load your profile.";
                    return RedirectToAction("Index", "Participant");
                }

                return View(profile);
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return View(new ParticipantProfileViewModel());
            }
        }

        // PARTICIPANT PROFILE - POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ParticipantProfile(
            ParticipantProfileViewModel model)
        {
            string? token = HttpContext.Session.GetString("JWToken");
            string? userRole = HttpContext.Session.GetString("UserRole");

            if (string.IsNullOrEmpty(token) || userRole != "Participant")
                return RedirectToAction("Login", "Auth");

            if (!ModelState.IsValid)
                return View(model);

            try
            {
                await _apiService.UpdateParticipantProfileAsync(model, token);

                TempData["Success"] =
                    "Your profile was updated successfully.";

                return RedirectToAction(nameof(ParticipantProfile));
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return View(model);
            }
        }

        // ORGANISER PROFILE - GET
        [HttpGet]
        public async Task<IActionResult> OrganiserProfile()
        {
            string? token = HttpContext.Session.GetString("JWToken");
            string? userRole = HttpContext.Session.GetString("UserRole");

            if (string.IsNullOrEmpty(token) || userRole != "Organiser")
                return RedirectToAction("Login", "Auth");

            try
            {
                var profile = await _apiService.GetOrganiserProfileAsync(token);

                if (profile == null)
                {
                    TempData["Error"] =
                        "Unable to load your organiser profile.";

                    return RedirectToAction("Index", "Organiser");
                }

                return View(profile);
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return View(new OrganiserProfileViewModel());
            }
        }

        // ORGANISER PROFILE - POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> OrganiserProfile(
            OrganiserProfileViewModel model)
        {
            string? token = HttpContext.Session.GetString("JWToken");
            string? userRole = HttpContext.Session.GetString("UserRole");

            if (string.IsNullOrEmpty(token) || userRole != "Organiser")
                return RedirectToAction("Login", "Auth");

            if (!ModelState.IsValid)
                return View(model);

            try
            {
                await _apiService.UpdateOrganiserProfileAsync(model, token);

                TempData["Success"] =
                    "Your organiser profile was updated successfully.";

                return RedirectToAction(nameof(OrganiserProfile));
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return View(model);
            }
        }

        // ORGANISER PROFILE IMAGE - POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UploadOrganiserProfileImage(
            IFormFile image)
        {
            string? token = HttpContext.Session.GetString("JWToken");
            string? userRole = HttpContext.Session.GetString("UserRole");

            if (string.IsNullOrEmpty(token) || userRole != "Organiser")
                return RedirectToAction("Login", "Auth");

            if (image == null || image.Length == 0)
            {
                TempData["Error"] = "Please select an image.";
                return RedirectToAction(nameof(OrganiserProfile));
            }

            try
            {
                await _apiService.UploadOrganiserProfileImageAsync(
                    image, token);

                TempData["Success"] =
                    "Your profile picture was uploaded successfully.";

                return RedirectToAction(nameof(OrganiserProfile));
            }
            catch (Exception ex)
            {
                TempData["Error"] = ex.Message;
                return RedirectToAction(nameof(OrganiserProfile));
            }
        }
    }
}
