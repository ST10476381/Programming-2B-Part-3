﻿
using System;
using System.ComponentModel.DataAnnotations;
using RaceDayMVC.Models;

namespace RaceDayMVC.Models
{
    public class CreateEventViewModel
    {
        [Required(ErrorMessage = "Event name is required.")]
        public string EventName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Event date is required.")]
        [DataType(DataType.Date)]
        public DateTime EventDate { get; set; }

        [Required(ErrorMessage = "Location is required.")]
        public string Location { get; set; } = string.Empty;

        public string? Description { get; set; }

        [Required(ErrorMessage = "Please select an event type.")]
        public string EventType { get; set; } = string.Empty;

        [Required(ErrorMessage = "Distance is required.")]
        [Range(0.1, 1000, ErrorMessage = "Enter a valid distance.")]
        public decimal Distance { get; set; }
    }
}
