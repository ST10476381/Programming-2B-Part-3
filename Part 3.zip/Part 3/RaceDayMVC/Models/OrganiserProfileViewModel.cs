﻿using System.ComponentModel.DataAnnotations;

namespace RaceDayMVC.Models
{
    public class OrganiserProfileViewModel
    {
        public int OrganiserID { get; set; }

        [Required]
        [StringLength(100)]
        public string Name { get; set; } = string.Empty;

        [Required]
        [EmailAddress]
        [StringLength(150)]
        public string Email { get; set; } = string.Empty;

        [Required]
        [Phone]
        [StringLength(20)]
        public string Phone { get; set; } = string.Empty;

        public string? ProfileImageUrl { get; set; }
    }
}