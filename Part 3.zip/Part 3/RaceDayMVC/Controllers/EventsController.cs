﻿using Microsoft.AspNetCore.Mvc;
using RaceDayMVC.Models;
using RaceDayMVC.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RaceDayMVC.Controllers
{
    public class EventsController : Controller
    {
        private readonly RaceDayApiService _apiService;

        public EventsController(RaceDayApiService apiService)
        {
            _apiService = apiService;
        }

        // ORGANISER: DISPLAY EVENTS
        public async Task<IActionResult> Index()
        {
            if (!IsOrganiser())
                return RedirectToAction("Login", "Auth");

            try
            {
                var events = await _apiService.GetEventsAsync();
                return View("ManageEvents", events);
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return View("ManageEvents", new List<EventViewModel>());
            }
        }

        // PARTICIPANT: BROWSE EVENTS
        public async Task<IActionResult> Browse()
        {
            if (!IsParticipant())
                return RedirectToAction("Login", "Auth");

            try
            {
                var events = await _apiService.GetEventsAsync();

                var upcomingEvents = events
                    .Where(e => e.EventDate.Date >= DateTime.Today)
                    .OrderBy(e => e.EventDate)
                    .ToList();

                return View("BrowseEvents", upcomingEvents);
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return View("BrowseEvents", new List<EventViewModel>());
            }
        }

        // ORGANISER: DISPLAY CREATE EVENT FORM
        [HttpGet]
        public IActionResult Create()
        {
            if (!IsOrganiser())
                return RedirectToAction("Login", "Auth");

            return View("CreateEvent");
        }

        // ORGANISER: SAVE NEW EVENT
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CreateEventViewModel model)
        {
            if (!IsOrganiser())
                return RedirectToAction("Login", "Auth");

            if (!ModelState.IsValid)
                return View("CreateEvent", model);

            try
            {
                string token = HttpContext.Session.GetString("JWToken")!;

                await _apiService.CreateEventAsync(model, token);

                TempData["Success"] = "Event created successfully!";

                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                return View("CreateEvent", model);
            }
        }

        // ORGANISER: DISPLAY EDIT EVENT FORM
        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            if (!IsOrganiser())
                return RedirectToAction("Login", "Auth");

            try
            {
                var events = await _apiService.GetEventsAsync();
                var selectedEvent = events.FirstOrDefault(e => e.EventID == id);

                if (selectedEvent == null)
                    return NotFound();

                var model = new CreateEventViewModel
                {
                    EventName = selectedEvent.EventName,
                    EventDate = selectedEvent.EventDate,
                    Location = selectedEvent.Location,
                    Description = selectedEvent.Description,
                    EventType = selectedEvent.EventType
                };

                return View("EditEvent", model);
            }
            catch (Exception ex)
            {
                return Content("Error loading event: " + ex.Message);
            }
        }

        // ORGANISER: SAVE EDITED EVENT
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, CreateEventViewModel model)
        {
            if (!IsOrganiser())
                return RedirectToAction("Login", "Auth");

            if (!ModelState.IsValid)
                return View("EditEvent", model);

            try
            {
                string token = HttpContext.Session.GetString("JWToken")!;

                await _apiService.UpdateEventAsync(id, model, token);

                TempData["Success"] = "Event updated successfully!";

                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                return View("EditEvent", model);
            }
        }

        // ORGANISER: DELETE EVENT
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            if (!IsOrganiser())
                return RedirectToAction("Login", "Auth");

            try
            {
                string token = HttpContext.Session.GetString("JWToken")!;

                await _apiService.DeleteEventAsync(id, token);

                TempData["Success"] = "Event deleted successfully!";

                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                TempData["Error"] = ex.Message;
                return RedirectToAction("Index");
            }
        }

        // CHECK ORGANISER LOGIN
        private bool IsOrganiser()
        {
            var token = HttpContext.Session.GetString("JWToken");
            var role = HttpContext.Session.GetString("UserRole");

            return !string.IsNullOrEmpty(token) && role == "Organiser";
        }

        // CHECK PARTICIPANT LOGIN
        private bool IsParticipant()
        {
            var token = HttpContext.Session.GetString("JWToken");
            var role = HttpContext.Session.GetString("UserRole");

            return !string.IsNullOrEmpty(token) && role == "Participant";
        }
    }
}