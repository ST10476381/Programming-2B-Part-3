﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using RaceDayMVC.Models;
using RaceDayMVC.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RaceDayMVC.Controllers
{
    public class EnrolmentsController : Controller
    {
        private readonly RaceDayApiService _apiService;

        public EnrolmentsController(RaceDayApiService apiService)
        {
            _apiService = apiService;
        }

        // PARTICIPANT: VIEW AVAILABLE CATEGORIES
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var token = HttpContext.Session.GetString("JWToken");
            var role = HttpContext.Session.GetString("UserRole");

            if (string.IsNullOrEmpty(token) || role != "Participant")
                return RedirectToAction("Login", "Auth");

            try
            {
                var categories = await _apiService.GetCategoriesAsync();

                return View("ParticipantEnrolments", categories);
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;

                return View("ParticipantEnrolments",
                    new List<CategoryViewModel>());
            }
        }

        // PARTICIPANT: SUBMIT ENROLMENT
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(int categoryId)
        {
            var token = HttpContext.Session.GetString("JWToken");
            var role = HttpContext.Session.GetString("UserRole");

            if (string.IsNullOrEmpty(token) || role != "Participant")
                return RedirectToAction("Login", "Auth");

            if (categoryId <= 0)
            {
                TempData["Error"] = "Please select a valid category.";
                return RedirectToAction("Index");
            }

            try
            {
                await _apiService.CreateEnrolmentAsync(categoryId, token);

                TempData["Success"] =
                    "You have successfully enrolled!";
            }
            catch (Exception ex)
            {
                TempData["Error"] = ex.Message;
            }

            return RedirectToAction("Index");
        }

        // PARTICIPANT: VIEW MY ENROLMENTS
        [HttpGet]
        public async Task<IActionResult> MyEnrolments()
        {
            var token = HttpContext.Session.GetString("JWToken");
            var role = HttpContext.Session.GetString("UserRole");

            if (string.IsNullOrEmpty(token) || role != "Participant")
                return RedirectToAction("Login", "Auth");

            try
            {
                var enrolments = await _apiService.GetEnrolmentsAsync(token);

                var participantId =
                    HttpContext.Session.GetString("UserId");

                var myEnrolments = enrolments
                    .Where(e => e.ParticipantID.ToString() == participantId)
                    .ToList();

                return View("MyEnrolments", myEnrolments);
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;

                return View("MyEnrolments",
                    new List<EnrolmentViewModel>());
            }
        }

        // ORGANISER: VIEW PARTICIPANT ENROLMENTS
        [HttpGet]
        public async Task<IActionResult> OrganiserIndex()
        {
            var token = HttpContext.Session.GetString("JWToken");
            var role = HttpContext.Session.GetString("UserRole");

            if (string.IsNullOrEmpty(token) || role != "Organiser")
                return RedirectToAction("Login", "Auth");

            try
            {
                var enrolments = await _apiService.GetEnrolmentsAsync(token);

                return View("OrganiserEnrolments", enrolments);
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;

                return View("OrganiserEnrolments",
                    new List<EnrolmentViewModel>());
            }
        }
    }
}