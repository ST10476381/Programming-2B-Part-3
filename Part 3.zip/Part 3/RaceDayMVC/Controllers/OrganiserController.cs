﻿
using Microsoft.AspNetCore.Mvc;

namespace RaceDayMVC.Controllers
{
    public class OrganiserController : Controller
    {
        public IActionResult Index()
        {
            var token = HttpContext.Session.GetString("JWToken");
            var role = HttpContext.Session.GetString("UserRole");

            if (string.IsNullOrEmpty(token) || role != "Organiser")
            {
                return RedirectToAction("Login", "Auth");
            }

            return View("OrganiserDashboard");
        }
    }
}
