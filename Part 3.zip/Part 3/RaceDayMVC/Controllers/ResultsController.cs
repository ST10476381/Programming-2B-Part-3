﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using RaceDayMVC.Models;
using RaceDayMVC.Services;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace RaceDayMVC.Controllers
{
    public class ResultsController : Controller
    {
        private readonly RaceDayApiService _apiService;

        public ResultsController(RaceDayApiService apiService)
        {
            _apiService = apiService;
        }

        // ORGANISER: VIEW ENROLMENTS
        public async Task<IActionResult> OrganiserIndex()
        {
            var token = HttpContext.Session.GetString("JWToken");
            var role = HttpContext.Session.GetString("UserRole");

            if (string.IsNullOrEmpty(token) || role != "Organiser")
                return RedirectToAction("Login", "Auth");

            try
            {
                var enrolments = await _apiService.GetEnrolmentsAsync(token);
                return View("OrganiserResults", enrolments);
            }
            catch (Exception ex)
            {
                ViewBag.Error = "Could not load enrolments: " + ex.Message;

                return View("OrganiserResults",
                    new List<EnrolmentViewModel>());
            }
        }

        // ORGANISER: SAVE RESULT
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ResultViewModel model)
        {
            var token = HttpContext.Session.GetString("JWToken");
            var role = HttpContext.Session.GetString("UserRole");

            if (string.IsNullOrEmpty(token) || role != "Organiser")
                return RedirectToAction("Login", "Auth");

            try
            {
                await _apiService.CreateResultAsync(model, token);
                TempData["Success"] = "Result captured successfully.";
            }
            catch (Exception ex)
            {
                TempData["Error"] = ex.Message;
            }

            return RedirectToAction("OrganiserIndex");
        }

        // PARTICIPANT: VIEW RESULTS
        public async Task<IActionResult> ParticipantIndex()
        {
            var token = HttpContext.Session.GetString("JWToken");
            var role = HttpContext.Session.GetString("UserRole");

            if (string.IsNullOrEmpty(token) || role != "Participant")
                return RedirectToAction("Login", "Auth");

            try
            {
                var results = await _apiService.GetResultsAsync(token);
                return View("ParticipantResults", results);
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;

                return View("ParticipantResults",
                    new List<ResultViewModel>());
            }
        }
    }
}
