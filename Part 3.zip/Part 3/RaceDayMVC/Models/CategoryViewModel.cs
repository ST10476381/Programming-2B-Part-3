﻿using System.ComponentModel.DataAnnotations;

namespace RaceDayMVC.Models
{
    public class CategoryViewModel
    {
        public int CategoryID { get; set; }

        [Required]
        public int EventId { get; set; }

        [Required(ErrorMessage = "Category name is required.")]
        public string CategoryName { get; set; } = string.Empty;

        [Required]
        [Range(0.1, 1000)]
        public decimal Distance { get; set; }

        [Required]
        [Range(1, 100000)]
        public int MaxParticipants { get; set; }

        [Required]
        [Range(0, 1000000)]
        public decimal EntryFee { get; set; }

        [Required]
        [Range(0, 120)]
        public int MinAge { get; set; }

        [Required]
        [Range(0, 120)]
        public int MaxAge { get; set; }
    }
}